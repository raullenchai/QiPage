import os
import tornado.httpserver
import tornado.ioloop
import tornado.web
import tornado.autoreload
from dropbox import client, rest, session
import urllib, urllib2, cookielib, httplib
import pymongo
from pymongo import Connection
import re

APP_KEY = '0tke3y6h1agey44'
APP_SECRET = 'h0rtcuilm0x435r'
ACCESS_TYPE = 'app_folder'
MAX_JOBS = 30
_VALID_URL = r'^((?:https?://)?(?:youtu\.be/|(?:\w+\.)?youtube(?:-nocookie)?\.com/)(?!view_play_list|my_playlists|artist|playlist)(?:(?:(?:v|embed|e)/)|(?:(?:watch(?:_popup)?(?:\.php)?)?(?:\?|#!?)(?:.+&)?v=))?)?([0-9A-Za-z_-]+)(?(1).+)?$'


#DB Design 123456
#db.user.insert({'display_name':'John P. User', 'uid':'12345678', 'country':'US', 'quota_shared':'253738410565', 'quota_quota':'107374182400000', 'quota_normal':'680031877871', 'email':'', 'key':'123', 'secret':'abc', 'running_jobs':'0'})
#db.workflow.insert({'url':'http://www.youtube.com/watch?v=U0jsin9iBQI&feature=g-all-u', 'title':'', 'type':'', 'width':'0', 'height':'0', 'size':'0', 'status':'waiting'})
#db.token.insert({'key':'123', 'secret':'abc', 'url':'http://www.youtube.com/watch?v=U0jsin9iBQI&feature=g-all-u', 'confirmed':'0'})
#confirmed: 0 -- wait to be authenticated
#			1 -- authenticated, wait to be download
#			2 -- start to download
#			3 -- downloaded, wait to be uploaded
#			4 -- error

class SubmitHandler(tornado.web.RequestHandler):

    def validate(self, url):
		# Extract video id from URL
		mobj = re.match(_VALID_URL, url)
		if mobj is None:
	         return
		return mobj.group(2)
		
    def post(self):
	    url= self.validate(self.get_argument('url'))
	    if url == None:
	        self.write("Invalid YouTube URL")
	    else:
	        sess = session.DropboxSession(APP_KEY, APP_SECRET, ACCESS_TYPE)
	        request_token = sess.obtain_request_token()
	        request_token_key = request_token.key
	        request_token_secret = request_token.secret

	        #save
	        dbtoken = self.application.db.token
	        dbtoken.insert({'key':request_token_key, 'secret':request_token_secret, 'url':url, 'confirmed':'0'})

	        dropbox_url = sess.build_authorize_url(request_token, oauth_callback="http://vps.raullen.com/authres")
	        self.write(
	        """
	        <html>
	        <head>
	        <meta http-equiv="REFRESH" content="0;url= %s "></HEAD>
	        <BODY>
	        </BODY>
	        </HTML>
	        """ % dropbox_url)


class AuthResHandler(tornado.web.RequestHandler):
    def get(self):
        request_token_key = self.get_argument('oauth_token')
		
		#lookup
        dbtoken = self.application.db.token
        request_token_secret = dbtoken.find_one({"key": request_token_key})['secret']

        sess = session.DropboxSession(APP_KEY, APP_SECRET, ACCESS_TYPE)
        request_token = session.OAuthToken(key = request_token_key, secret = request_token_secret)
        access_token = sess.obtain_access_token(request_token)
        myclient = client.DropboxClient(sess)
        user = myclient.account_info()
		
        dbuser = self.application.db.user
        if dbuser.find_one({"uid": str(user['uid'])}) == None:
		    dbuser.insert({'display_name':user['display_name'], 'uid':str(user['uid']), 'country':user['country'], 'quota_shared':str(user['quota_info']['shared']), 'quota_quota':str(user['quota_info']['quota']), 'quota_normal':str(user['quota_info']['normal']), 'email':'', 'key':access_token.key, 'secret':access_token.secret, 'running_jobs':'0'})
        else:
		    dbuser.update({'uid':str(user['uid'])}, {"$set":{'key':access_token.key}} )
		    dbuser.update({'uid':str(user['uid'])}, {"$set":{'secret':access_token.secret}} )

        jobs = int(dbuser.find_one({"uid": str(user['uid'])})['running_jobs'])
        if jobs < MAX_JOBS:
		    dbtoken = self.application.db.token
		    dbtoken.update({'key':request_token.key}, {"$set":{'confirmed':'1'}})
		    dbtoken.update({'key':request_token.key}, {"$set":{'secret':access_token.secret}})
		    dbtoken.update({'secret':access_token.secret}, {"$set":{'key':access_token.key}})
		    dbuser.update({'uid':str(user['uid'])}, {"$set":{'running_jobs':str(jobs+1)}})
		    self.write('You will receive your video in couple of minutes!')

        else:
		    self.write('reject url as maximum allowing jobs is reached')

        '''
        f = open('/home/YouDropIn/Ebt9vnaXyMc.flv')
        response = myclient.put_file('/Ebt9vnaXyMc.flv', f)
        self.write("uploaded:" + str(response))
        '''


class IndexHandler(tornado.web.RequestHandler):
    def get(self):
        self.render("index.html")


class Application(tornado.web.Application):
    def __init__(self):
        settings = dict(
        template_path = os.path.join(os.path.dirname('/home/YouDropIn/templates'), "templates"),
        static_path = os.path.join(os.path.dirname('/home/YouDropIn/static'), "static"),
        debug = True
        )
        handlers = [(r"/", IndexHandler), (r"/submit", SubmitHandler), (r"/authres", AuthResHandler)]
        conn = Connection("localhost", 27017)
        self.db = conn["example"]
        tornado.web.Application.__init__(self, handlers, **settings)


if __name__ == "__main__":
    #application.listen(80)
	http_server = tornado.httpserver.HTTPServer(Application())
	http_server.listen(80)
	tornado.ioloop.IOLoop.instance().start()