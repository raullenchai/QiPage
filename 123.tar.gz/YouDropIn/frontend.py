import os
import tornado.httpserver
import tornado.ioloop
import tornado.web
import tornado.autoreload
from dropbox import client, rest, session
import urllib, urllib2, cookielib, httplib
import pymongo
from pymongo import Connection
import re

APP_KEY = '0tke3y6h1agey44'
APP_SECRET = 'h0rtcuilm0x435r'
ACCESS_TYPE = 'app_folder'
MAX_JOBS = 100
_VALID_URL = r'^((?:https?://)?(?:youtu\.be/|(?:\w+\.)?youtube(?:-nocookie)?\.com/)(?!view_play_list|my_playlists|artist|playlist)(?:(?:(?:v|embed|e)/)|(?:(?:watch(?:_popup)?(?:\.php)?)?(?:\?|#!?)(?:.+&)?v=))?)?([0-9A-Za-z_-]+)(?(1).+)?$'


#DB Design 123456
#db.user.insert({'display_name':'John P. User', 'uid':'12345678', 'country':'US', 'quota_shared':'253738410565', 'quota_quota':'107374182400000', 'quota_normal':'680031877871', 'email':'', 'key':'123', 'secret':'abc', 'running_jobs':'0'})
#db.workflow.insert({'url':'http://www.youtube.com/watch?v=U0jsin9iBQI&feature=g-all-u', 'title':'', 'type':'', 'width':'0', 'height':'0', 'size':'0', 'status':'waiting'})
#db.token.insert({'key':'123', 'secret':'abc', 'url':'http://www.youtube.com/watch?v=U0jsin9iBQI&feature=g-all-u', 'vid':'U0jsin9iBQI', 'confirmed':'0'})
#confirmed: 0 -- wait to be authenticated
#			1 -- authenticated, wait to be download
#			2 -- start to download
#			3 -- downloaded, wait to be uploaded
#			4 -- uploading error, try later

class SubmitHandler(tornado.web.RequestHandler):

    def validate(self, url):
		# Extract video id from URL
		mobj = re.match(_VALID_URL, url)
		if mobj is None:
	         return
		return mobj.group(2)
		

    def get(self):
	        self.render("index.html", message='Youtube URL Goes Here', color='FF0000')
	        return
			
			
    def post(self):
	    try:
	        url = self.get_argument('url')
	    except:
	        self.render("index.html", message='Youtube URL Goes Here', color='FF0000')
	        return
			
	    vid = self.validate(url)
		
	    if vid == None:
	        self.render("index.html", message='Invalid YouTube URL', color='FF0000')
	        return
	    
	    if (not self.get_secure_cookie("YouDropIn_key")) or (not self.get_secure_cookie("YouDropIn_secret")):
	        #cookie was not set yet
	        sess = session.DropboxSession(APP_KEY, APP_SECRET, ACCESS_TYPE)
	        request_token = sess.obtain_request_token()
	        request_token_key = request_token.key
	        request_token_secret = request_token.secret

	        #save
	        dbtoken = self.application.db.token
	        dbtoken.insert({'key':request_token_key, 'secret':request_token_secret, 'url':url, 'vid':vid, 'confirmed':0})

	        dropbox_url = sess.build_authorize_url(request_token, oauth_callback="http://vps.raullen.com/authres")
	        self.write(
	        """
	        <html>
	        <head>
	        <meta http-equiv="REFRESH" content="0;url= %s "></HEAD>
	        <BODY>
	        </BODY>
	        </HTML>
	        """ % dropbox_url)
	    else:
			access_token_key = self.get_secure_cookie("YouDropIn_key")
			access_token_secret = self.get_secure_cookie("YouDropIn_secret")	
			#self.write(self.get_secure_cookie("YouDropIn_key"))
			#self.write(self.get_secure_cookie("YouDropIn_secret"))

			dbtoken = self.application.db.token
			dbuser = self.application.db.user
			if dbuser.find({"key": access_token_key}).count() == 0:
				#cookie was set but user's record cannot be located in db
				sess = session.DropboxSession(APP_KEY, APP_SECRET, ACCESS_TYPE)
				request_token = sess.obtain_request_token()
				request_token_key = request_token.key
				request_token_secret = request_token.secret

				#save
				dbtoken = self.application.db.token
				dbtoken.insert({'key':request_token_key, 'secret':request_token_secret, 'url':url, 'vid':vid, 'confirmed':0})

				dropbox_url = sess.build_authorize_url(request_token, oauth_callback="http://vps.raullen.com/authres")
				self.write(
				"""
				<html>
				<head>
				<meta http-equiv="REFRESH" content="0;url= %s "></HEAD>
				<BODY>
				</BODY>
				</HTML>
				""" % dropbox_url)
				return
			
			jobs = int(dbuser.find_one({"key": access_token_key})['running_jobs'])
			if jobs < MAX_JOBS:
				if dbtoken.find({'key':access_token_key, 'secret':access_token_secret, 'vid':vid}).count() == 0:
					dbtoken.insert({'key':access_token_key, 'secret':access_token_secret, 'url':url, 'vid':vid, 'confirmed':1})
					dbuser.update({'key':access_token_key}, {"$set":{'running_jobs':str(jobs+1)}})
					self.render("index.html", message='You Video Will Be Delivered in Couple of Minutes!', color='886A08')
				else:
					self.render("index.html", message='Your Video is Already in the Processing Queue!', color='886A08')
			else:
				self.render("index.html", message='Maximum Number of Jobs Reached', color='FF0000')
			
			
class AuthResHandler(tornado.web.RequestHandler):

    def post(self):
	    self.render("index.html", message='Youtube URL Goes Here', color='FF0000')
	    return
			
    def get(self):
        try:
			request_token_key = self.get_argument('oauth_token')
        except:
			self.render("index.html", message='Youtube URL Goes Here', color='FF0000')
			return

		#lookup
        dbtoken = self.application.db.token
        request_token_secret = dbtoken.find_one({"key": request_token_key})

		#start it over when there is no valid token
        if request_token_secret == None:
			self.write(
				"""
				<html>
				<head>
				<meta http-equiv="REFRESH" content="0;url= http://vps.raullen.com/ "></HEAD>
				<BODY>
				</BODY>
				</HTML>
				""")
			return
        else:
			request_token_secret = request_token_secret['secret']	

        sess = session.DropboxSession(APP_KEY, APP_SECRET, ACCESS_TYPE)
        request_token = session.OAuthToken(key = request_token_key, secret = request_token_secret)
        access_token = sess.obtain_access_token(request_token)
        myclient = client.DropboxClient(sess)
        user = myclient.account_info()
		
        self.set_secure_cookie("YouDropIn_key", access_token.key)
        self.set_secure_cookie("YouDropIn_secret", access_token.secret)

        dbuser = self.application.db.user
        if dbuser.find_one({"uid": str(user['uid'])}) == None:
		    dbuser.insert({'display_name':user['display_name'], 'uid':str(user['uid']), 'country':user['country'], 'quota_shared':str(user['quota_info']['shared']), 'quota_quota':str(user['quota_info']['quota']), 'quota_normal':str(user['quota_info']['normal']), 'email':'', 'key':access_token.key, 'secret':access_token.secret, 'running_jobs':'0'})
        else:
		    dbuser.update({'uid':str(user['uid'])}, {"$set":{'key':access_token.key}} )
		    dbuser.update({'uid':str(user['uid'])}, {"$set":{'secret':access_token.secret}} )

        jobs = int(dbuser.find_one({"uid": str(user['uid'])})['running_jobs'])
        if jobs < MAX_JOBS:
		    dbtoken.update({'key':request_token.key}, {"$set":{'confirmed':1}})
		    dbtoken.update({'key':request_token.key}, {"$set":{'secret':access_token.secret}})
		    dbtoken.update({'secret':access_token.secret}, {"$set":{'key':access_token.key}})
		    dbuser.update({'uid':str(user['uid'])}, {"$set":{'running_jobs':str(jobs+1)}})
		    self.render("index.html", message='You Video Will Be Delivered in Couple of Minutes!', color='886A08')

        else:
		    self.render("index.html", message='Maximum Number of Jobs Reached', color='FF0000')
			

'''
class MainHandler(tornado.web.RequestHandler):
	def get(self):
		if (not self.get_secure_cookie("YouDropIn_key")) or (not self.get_secure_cookie("YouDropIn_secret")):
			self.set_secure_cookie("YouDropIn_key", "raullen")
			self.set_secure_cookie("YouDropIn_secret", "lalalalla")
			self.write("Your cookie was not set yet!")
		else:
			self.write("Your cookie was set to " + self.get_secure_cookie("YouDropIn_key") + self.get_secure_cookie("YouDropIn_secret"))
'''


class IndexHandler(tornado.web.RequestHandler):
    def head(self):
        self.render("index.html", message='Youtube URL Goes Here', color='000000')
    
    def get(self):
        self.render("index.html", message='Youtube URL Goes Here', color='000000')

    def post(self):
        self.render("index.html", message='Youtube URL Goes Here', color='000000')
		
    def delete(self):
        self.render("index.html", message='Youtube URL Goes Here', color='000000')

    def patch(self):
        self.render("index.html", message='Youtube URL Goes Here', color='000000')
		
    def put(self):
        self.render("index.html", message='Youtube URL Goes Here', color='000000')
		
    def options(self):
        self.render("index.html", message='Youtube URL Goes Here', color='000000')				

class ErrorHandler(tornado.web.RequestHandler):
    def get(self):
        self.render("index.html", message='Youtube URL Goes Here', color='000000')
    
    def post(self):
        self.render("index.html", message='Youtube URL Goes Here', color='000000')
		

class Application(tornado.web.Application):
    def __init__(self):
        settings = dict(
        template_path = os.path.join(os.path.dirname('/home/YouDropIn/templates'), "templates"),
        static_path = os.path.join(os.path.dirname('/home/YouDropIn/static'), "static"),
		cookie_secret = "4cccba8e9300c02d0f2983dbe966d6d9792223b9904619eb77f4513171d351bc",
		xsrf_cookies = True,
		debug = True
		)
        handlers = [(r"/", IndexHandler), (r"/submit", SubmitHandler), (r"/authres", AuthResHandler), (r"/.*", ErrorHandler)]
        conn = Connection("localhost", 27017)
        self.db = conn["example"]
        tornado.web.Application.__init__(self, handlers, **settings)

if __name__ == "__main__":
    #application.listen(80)
	http_server = tornado.httpserver.HTTPServer(Application())
	http_server.listen(80)
	tornado.ioloop.IOLoop.instance().start()
