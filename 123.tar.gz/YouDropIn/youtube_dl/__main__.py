#!/usr/bin/env python
# -*- coding: utf-8 -*-

import __init__

if __name__ == '__main__':
	__init__.main()
