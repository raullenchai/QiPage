import os, sys
import tornado.httpserver
import tornado.ioloop
import tornado.web
import tornado.autoreload
from dropbox import client, rest, session
import urllib, urllib2, cookielib, httplib
import pymongo
from pymongo import Connection
import re
import threading
import time
try:
	from urlparse import parse_qs
except ImportError:
	from cgi import parse_qs


APP_KEY = '0tke3y6h1agey44'
APP_SECRET = 'h0rtcuilm0x435r'
ACCESS_TYPE = 'app_folder'
_VALID_URL = r'^((?:https?://)?(?:youtu\.be/|(?:\w+\.)?youtube(?:-nocookie)?\.com/)(?!view_play_list|my_playlists|artist|playlist)(?:(?:(?:v|embed|e)/)|(?:(?:watch(?:_popup)?(?:\.php)?)?(?:\?|#!?)(?:.+&)?v=))?)?([0-9A-Za-z_-]+)(?(1).+)?$'
WAIT_TIME = 60

class Download_Worker(threading.Thread):
	def __init__(self, t_name, t_num):  
		threading.Thread.__init__(self, name = t_name)
		self.name = t_name
		self.num = t_num
		
		#connect mongodb
		conn = Connection("localhost", 27017)
		self.db = conn["example"]
		self.start()

	def run(self):
		while True:
			#read the oldest url from db.token where confirmed == 1, 
			vid = 'I got nothing'
			target_url = ''
			for s in self.db.token.find({'confirmed':1}).sort( [['_id', 1]] ).limit(1):
				vid = s['vid']
				target_url = s['url']
			
			if vid == 'I got nothing':
				#print self.name + ' sleep'
				[time.sleep(1) for i in range(WAIT_TIME)]
			else:
				#print vid
				if self.db.workflow.find({'id':vid}).count() > 0:
					#vid has been downloaded previously
					self.db.token.update({'vid':vid}, {"$set":{'confirmed':3}}, multi=True)
					self.db.workflow.update({'id':vid}, {"$inc":{'hit':1}})
					print self.name + 'vid has been downloaded previously'
				elif self.db.token.find({'vid':vid, 'confirmed':2}).count() > 0:
					#vid is been downloading by other threads
					print self.name + ' vid is been downloading by other threads'
					self.db.token.update({'vid':vid}, {"$set":{'confirmed':2}}, multi=True)
				else:
					self.db.token.update({'vid':vid}, {"$set":{'confirmed':2}}, multi=True)
					#download the youtube file and save it to /vd_cache
					#update db.workflow with the obtained video info.
					para = 'cd /home/YouDropIn/youtube_dl/; python __main__.py --quiet ' + target_url
					#print para
					os.system(para)


class Upload_Worker(threading.Thread):
	def __init__(self, t_name, t_num):  
		threading.Thread.__init__(self, name = t_name)
		self.name = t_name
		self.num = t_num

		conn = Connection("localhost", 27017)
		self.db = conn["example"]
		self.start() 
		
	def run(self):
		while True:
			#read the oldest (vid, secret, key) from db.token where confirmed == 3, 
			vid = 'I got nothing'
			access_token = ''
			access_token_secret = ''
			for s in self.db.token.find({'confirmed':3}).sort( [['_id', 1]]).limit(1):
				vid = s['vid']
				access_token = s['key']
				access_token_secret = s['secret']
						
			if vid == 'I got nothing':
				#print self.name + ' sleep'
				time.sleep(WAIT_TIME)
			else:
				#upload it to the user's dropbox
				sess = session.DropboxSession(APP_KEY, APP_SECRET, ACCESS_TYPE)
				sess.set_token(access_token, access_token_secret)
				myclient = client.DropboxClient(sess)
				try:
					user = myclient.account_info()
				except rest.ErrorResponse, err:
					self.db.token.update({'key':access_token, 'secret':access_token_secret}, {"$set":{'confirmed':4}})
					if err.status == 401:
						print self.name + ' token error!'
					else:
						print self.name + ' unexpected error!'
					return

				filename = self.db.workflow.find_one({'id':vid})['filename']
				#print filename
				#TODO: how to support different languages
				try:
					statinfo = os.stat('/home/YouDropIn/vd_cache/'+filename)
					if (statinfo.st_size > 150000000):
						print 'Oversized, Skip!'
						self.db.token.update({'vid':vid, 'key':access_token, 'secret':access_token_secret}, {"$set":{'confirmed':4}})
					else:
						#uploading
						f = open('/home/YouDropIn/vd_cache/'+filename)
						print self.name + ' uploading [' + vid + ']'
						response = myclient.put_file(filename, f)
						print self.name + ' ' + str(response)
						#delete the current record from db.token
						self.db.token.remove({'vid':vid, 'key':access_token, 'secret':access_token_secret})
				except:
					self.db.token.update({'vid':vid, 'key':access_token, 'secret':access_token_secret}, {"$set":{'confirmed':4}})
					print self.name + ' upload error'


class Clean_Worker(threading.Thread):
	def __init__(self, t_name, t_num):  
		threading.Thread.__init__(self, name = t_name)
		self.name = t_name
		self.num = t_num

		conn = Connection("localhost", 27017)
		self.db = conn["example"]
		self.start()

	def run(self):
		while True:
			time.sleep(10*WAIT_TIME)
			#remove records from db.token where confirmed == 0 or 4
			for s in self.db.token.find({'confirmed':0}).sort( [['_id', 1]]):
				print self.name + ' removing unconfirmed video -- [' + s['vid'] + ']'
			
			self.db.token.remove({'confirmed':0})
			
			for s in self.db.token.find({'confirmed':4}).sort( [['_id', 1]]):
				print self.name + ' removing undownloadable video -- [' + s['vid'] + ']'

			self.db.token.remove({'confirmed':4})


if __name__ == '__main__':
	i = 1
	dthread1 = Download_Worker('Dloader-'+str(i), 200)
	uthread1 = Upload_Worker('Uloader-'+str(i), 200)
	cthread1 = Clean_Worker('Cleaner-'+str(i), 2)
